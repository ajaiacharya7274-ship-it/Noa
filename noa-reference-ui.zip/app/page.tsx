'use client'

import { useEffect, useState } from 'react'
import styles from './page.module.css'

const bars = [4,7,11,8,15,22,30,18,27,36,22,15,9,20,29,37,24,17,26,34,21,13,8,5]

export default function Page() {
  const [listening, setListening] = useState(false)

  useEffect(() => {
    if (!listening) return
    const t = window.setTimeout(() => setListening(false), 2400)
    return () => window.clearTimeout(t)
  }, [listening])

  return (
    <main className={styles.container}>
      <section className={styles.scene} aria-label="NOA assistant interface">
        <div className={`${styles.core} ${listening ? styles.coreListening : ''}`}>
          <div className={styles.outerGlow} />
          <div className={`${styles.orbit} ${styles.orbitOne}`} />
          <div className={`${styles.orbit} ${styles.orbitTwo}`} />
          <div className={`${styles.orbit} ${styles.orbitThree}`} />
          <div className={styles.particles}><i/><i/><i/><i/><i/><i/></div>
          <div className={styles.waveform}>
            {bars.map((h, i) => <span key={i} className={styles.bar} style={{height:`${h}px`,animationDelay:`${i*35}ms`}} />)}
          </div>
          <div className={styles.state}>{listening ? 'LISTENING' : 'IDLE'}</div>
        </div>

        <button
          className={`${styles.micButton} ${listening ? styles.micActive : ''}`}
          type="button"
          aria-label={listening ? 'Stop listening' : 'Start listening'}
          onClick={() => setListening(v => !v)}
        >
          <svg viewBox="0 0 24 24" aria-hidden="true">
            <rect x="9" y="3" width="6" height="11" rx="3"/>
            <path d="M6.5 11.5a5.5 5.5 0 0 0 11 0M12 17v4M9 21h6"/>
          </svg>
        </button>
      </section>
    </main>
  )
}
